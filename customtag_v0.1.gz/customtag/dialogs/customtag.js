/*
* @file CustomTag dialog for CKEditor
* Copyright (C) 2011 @paul_tanner
* Inspired by Video plugin by Alfonso Martínez de Lizarrondo
* For licensing see LICENSE.html or http://ckeditor.com/license
*/
(function() {
  function customtagDialog( editor, isEdit ) {
    var args=[],tname=null;
    return {
      title : 'Custom Tag',
      minWidth : 300,
      minHeight : 80,
      contents : [
        {
          id : 'info',
          label : 'Tag',
          title : 'Tag',
          elements : [
            {
              type : 'select',
              items : [
                [ 'test' ],
                [ 'list' ],
                [ 'edit' ]
              ],
              id : 'tname',
              label : 'TagName',
              'default' : 'test',
              required : true,
              setup : function( element ) {
                if ( isEdit ) this.setValue( tname );
              },
              commit : function( element ) {
                tname = this.getValue();
              }
            },
            {
              type : 'text',
              id : 'arg1',
              label : 'Arg1',
              'default' : '',
              required : true,
              setup : function( element ) {
                if ( isEdit ) this.setValue( args[0] );
              },
              commit : function( element ) {
                args[0] = this.getValue();
              }
            },
            {
              type : 'text',
              id : 'arg2',
              label : 'Arg2',
              'default' : '',
              required : true,
              setup : function( element ) {
                if ( isEdit ) this.setValue( args[1] );
              },
              commit : function( element ) {
                args[1] = this.getValue();
              }
            },
            {
              type : 'text',
              id : 'arg3',
              label : 'Arg3',
              'default' : '',
              required : true,
              setup : function( element ) {
                if ( isEdit ) this.setValue( args[2] );
              },
              commit : function( element ) {
                args[2] = this.getValue();
              }
            },
            {
              type : 'text',
              id : 'arg4',
              label : 'Arg4',
              'default' : '',
              required : true,
              setup : function( element ) {
                if ( isEdit ) this.setValue( args[3] );
              },
              commit : function( element ) {
                args[3] = this.getValue();
              }
            }
          ]
        }
      ],
      onShow : function() {
        if ( isEdit ) {
          var fakeImage = this.getSelectedElement();
          if ( fakeImage && fakeImage.data( 'cke-real-element-type' ) ) {
            tname=fakeImage.data( 'cke-real-element-type' );
            this.fakeImage = fakeImage;
            var customNode = editor.restoreRealElement( fakeImage );
            args[0]=customNode.getAttribute("arg1");
            args[1]=customNode.getAttribute("arg2");
            args[2]=customNode.getAttribute("arg3");
            args[3]=customNode.getAttribute("arg4");
          }
        }
        this.customNode = customNode;
        this.setupContent( this._element );
      },
      onOk : function() {
        var customNode = null;
        this.commitContent();

        // remake the node in case the type has changed
        customNode = CKEDITOR.dom.element.createFromHtml( '<cke:'+tname+' />', editor.document );
        if (args[0].length > 0) customNode.setAttributes({ 'arg1': args[0] });
        if (args[1].length > 0) customNode.setAttributes({ 'arg2': args[1] });
        if (args[2].length > 0) customNode.setAttributes({ 'arg3': args[2] });
        if (args[3].length > 0) customNode.setAttributes({ 'arg4': args[3] });

        var newFakeImage = editor.createFakeElement( customNode, 'cke_'+tname, tname, false );
        if ( this.fakeImage ) {
          newFakeImage.replace( this.fakeImage );
          editor.getSelection().selectElement( newFakeImage );
        }
        else
      	  editor.insertElement( newFakeImage );
      }
    }
  }

  CKEDITOR.dialog.add( 'createcustomtag', function( editor ) {
      return customtagDialog( editor );
    });
  CKEDITOR.dialog.add( 'editcustomtag', function( editor ) {
      return customtagDialog( editor, 1 );
    });
} )();
