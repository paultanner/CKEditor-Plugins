﻿/*
* @file CustomTag plugin for CKEditor
* Copyright (C) 2011 @paul_tanner
* Inspired by Video plugin by Alfonso MartÃ­nez de Lizarrondo
* For licensing see LICENSE.html or http://ckeditor.com/license 
*/
(function() {
  var newTag = {
    ExtendDtd : function () {
      var tagName = arguments[0];
      var tagName2 = 'cke:'+tagName;
      var dtd = CKEDITOR.dtd;
      dtd[tagName] = 1;
      dtd[tagName2] = 1;
      for (var i=1; i<arguments.length; i++) {
         dtd[arguments[i]][tagName] = 1;
         dtd[arguments[i]][tagName2] = 1;
      }
    }
  }

  CKEDITOR.plugins.add( 'customtag', {
    requires : [ 'fakeobjects', 'dialog' ],
    lang : [ 'en' ],
  
    init : function( editor ) {
      var lang = editor.lang.customtag;
  
      // Check for CKEditor 3.5
      if (typeof editor.element.data == 'undefined') {
        alert('The "Customtag" plugin requires CKEditor 3.5 or newer');
        return;
      }
  
      // add commands
      editor.addCommand( 'createcustomtag', new CKEDITOR.dialogCommand( 'createcustomtag' ) );
      editor.addCommand( 'editcustomtag', new CKEDITOR.dialogCommand( 'editcustomtag' ) );
  
      // add create button
      editor.ui.addButton( 'CreateCustomTag', {
          label : lang.toolbar,
          command : 'createcustomtag',
          icon : this.path + 'images/icon.png'
        }
      );
  
      // handle edit command
      editor.on( 'doubleclick', function( evt ) {
        var element = evt.data.element;
        if ( element.is( 'img' ) ) {
          var rtype = element.data( 'cke-real-element-type' );
          if ( rtype == 'test' || rtype == 'list' || rtype == 'edit' )
            evt.data.dialog = 'editcustomtag';
        }
      });

      // define extra dtd elements
      newTag.ExtendDtd ('test','$empty','$block','body','p');
      newTag.ExtendDtd ('list','$empty','$block','body','p');
      newTag.ExtendDtd ('edit','$empty','$block','body','p');
  
      // and their respective css treatments
      editor.addCss(
        'img.cke_test' + '{' +
        'background-image: url(' + CKEDITOR.getUrl( this.path + 'images/test.png' ) + ');' +
          'background-repeat:no-repeat;width:30px;height:14px;margin-left:4px;margin-right:4px;' +
        '}'
      );
      editor.addCss(
        'img.cke_list' + '{' +
        'background-image: url(' + CKEDITOR.getUrl( this.path + 'images/list.png' ) + ');' +
          'background-repeat:no-repeat;width:30px;height:14px;margin-left:4px;margin-right:4px' +
        '}'
      );
      editor.addCss(
        'img.cke_edit' + '{' +
        'background-image: url(' + CKEDITOR.getUrl( this.path + 'images/edit.png' ) + ');' +
          'background-repeat:no-repeat;width:30px;height:14px;margin-left:4px;margin-right:4px' +
        '}'
      );
  
      // add dialog functions
      CKEDITOR.dialog.add( 'createcustomtag', this.path + 'dialogs/customtag.js' );
      CKEDITOR.dialog.add( 'editcustomtag', this.path + 'dialogs/customtag.js' );
    }, //init

    afterInit: function( editor ) {
      var dataProcessor = editor.dataProcessor,
        dataFilter = dataProcessor.dataFilter;
  
      // conversion from html input to internal data for additional tags
      dataFilter.addRules({
  
        elements : {
          'test' : function( element ) {
              return editor.createFakeParserElement( element, 'cke_test', 'test', false );
           },
          'list' : function( element ) {
              return editor.createFakeParserElement( element, 'cke_list', 'list', false );
           },
          'edit' : function( element ) {
              return editor.createFakeParserElement( element, 'cke_edit', 'edit', false );
           }
         }
  
      }); //df.addRules
  
    } //afterInit
  
  }); // add
} )();
